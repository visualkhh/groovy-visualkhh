Readme File
2013/10/07-22:25:51
This package contains HyperSQL v. 2.3.1

HyperSQL is a relational database engine and a set of tools written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
