package _14

import _14.oldpack._14_A as GO;

class A_14_A extends GO {
	public def calc(def a, def b){
		return a*b;
	}
}
def  f =  new A_14_A();
println f.calc(4,4);
