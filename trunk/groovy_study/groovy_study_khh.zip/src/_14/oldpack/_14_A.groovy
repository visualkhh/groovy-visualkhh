package _14.oldpack

public class _14_A {
	public def calc(def a, def b){
		return a+b;
	}
}
