package _2.sub

class GClass {
	private private_var='private_var';
	public public_var='public_var';
	protected protected_var='protected_var';
	def def_var ='def_var';
}

