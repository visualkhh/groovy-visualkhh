new Date().identity{
	println "$date.$month.$year"
}
class G_1{
	def g1=044;
}
new G_1().identity{
	println "$g1"
}